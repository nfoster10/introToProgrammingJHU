public class NullPointerExceptionThrown
{
	public static void main(String[]args)
	{
		String nullString = null;
		nullString.contains("1");
	}
}